﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Routes
{
    /// <summary>
    /// Interaction logic for RoutesUpdateView.xaml
    /// </summary>
    public partial class RoutesUpdateView : UserControl
    {
        public RoutesUpdateView()
        {
            InitializeComponent();
        }
    }
}
