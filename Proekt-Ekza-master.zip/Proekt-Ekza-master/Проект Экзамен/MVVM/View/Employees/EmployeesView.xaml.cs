﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Employees
{
    /// <summary>
    /// Interaction logic for EmployeesView.xaml
    /// </summary>
    public partial class EmployeesView : UserControl
    {
        public EmployeesView()
        {
            InitializeComponent();
        }
    }
}
