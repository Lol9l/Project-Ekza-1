﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View;

/// <summary>
/// Interaction logic for LoginView.xaml
/// </summary>
public partial class LoginView : UserControl
{
    public LoginView()
    {
        InitializeComponent();
    }
}
