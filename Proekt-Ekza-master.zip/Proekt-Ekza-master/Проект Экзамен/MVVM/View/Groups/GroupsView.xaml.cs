﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Groups
{
    /// <summary>
    /// Interaction logic for GroupsView.xaml
    /// </summary>
    public partial class GroupsView : UserControl
    {
        public GroupsView()
        {
            InitializeComponent();
        }
    }
}
