﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Groups
{
    /// <summary>
    /// Interaction logic for GroupsCreateView.xaml
    /// </summary>
    public partial class GroupsCreateView : UserControl
    {
        public GroupsCreateView()
        {
            InitializeComponent();
        }
    }
}
