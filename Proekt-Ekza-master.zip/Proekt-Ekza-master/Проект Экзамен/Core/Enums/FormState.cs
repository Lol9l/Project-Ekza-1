﻿namespace Travel_Company.WPF.Core.Enums;

public enum FormState
{
    None,
    Updating,
    Inserting
}