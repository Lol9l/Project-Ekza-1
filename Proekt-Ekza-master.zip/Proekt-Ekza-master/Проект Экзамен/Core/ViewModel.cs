﻿namespace Travel_Company.WPF.Core;

public abstract class ViewModel : ObservableObject { }