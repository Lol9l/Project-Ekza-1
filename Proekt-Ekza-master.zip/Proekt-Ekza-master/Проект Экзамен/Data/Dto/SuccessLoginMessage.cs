﻿namespace Travel_Company.WPF.Data.Dto;

public class SuccessLoginMessage
{
    public bool Success { get; set; } = true;
}