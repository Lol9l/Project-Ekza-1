﻿using Travel_Company.WPF.Core.Enums;

namespace Travel_Company.WPF.Data.Dto;

public class CatalogTypeMessage
{
    public CatalogType CatalogType { get; set; }
}