﻿using Travel_Company.WPF.Models;

namespace Travel_Company.WPF.Data.Dto;

public class TourGuideMessage
{
    public TourGuide TourGuide { get; set; } = null!;
}