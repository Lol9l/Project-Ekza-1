﻿using Travel_Company.WPF.Models;

namespace Travel_Company.WPF.Data.Dto;

public class ClientMessage
{
    public Client Client { get; set; } = null!;
}