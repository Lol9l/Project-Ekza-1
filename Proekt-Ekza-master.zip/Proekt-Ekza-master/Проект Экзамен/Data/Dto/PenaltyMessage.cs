﻿using Travel_Company.WPF.Models;

namespace Travel_Company.WPF.Data.Dto;

public class PenaltyMessage
{
    public Penalty Penalty { get; set; } = null!;
}