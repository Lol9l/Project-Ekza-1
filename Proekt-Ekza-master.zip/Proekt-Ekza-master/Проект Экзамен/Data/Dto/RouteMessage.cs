﻿using Travel_Company.WPF.Models;

namespace Travel_Company.WPF.Data.Dto;

public class RouteMessage
{
    public Route Route { get; set; } = null!;
}